/*  Given an array of integers representing the histogram bar's height where the width of each bar is 1.
    return the area of largest area of rectangle in histogram.      */

#include <iostream>
#include <vector>
#include <climits>
#include <stack>
using namespace std;

vector<int> nextSmallerElement(vector<int> &height, int n)
{
    stack<int> s;
    s.push(-1);

    vector<int> ans(n);

    for (int i = n - 1; i >= 0; i--)
    {
        while ((s.top() != -1) && (height[s.top()] >= height[i]))
        {
            s.pop();
        }
        ans[i] = s.top();
        s.push(i);
    }
    return ans;
}

vector<int> prevSmallerElement(vector<int> &height, int n)
{
    stack<int> s;
    s.push(-1);

    vector<int> ans(n);

    for (int i = 0; i < n; i++)
    {
        while ((s.top() != -1) && (height[s.top()] >= height[i]))
        {
            s.pop();
        }
        ans[i] = s.top();
        s.push(i);
    }
    return ans;
}

int largestAreaRectangle(vector<int> &height)
{
    int n = height.size();

    vector<int> next(n);

    next = nextSmallerElement(height, n);

    vector<int> prev(n);
    prev = prevSmallerElement(height, n);

    int area = INT_MIN;
    for (int i = 0; i < n; i++)
    {
        int l = height[i];

        if (next[i] == -1)
        {
            next[i] = n;
        }

        int b = next[i] - prev[i] - 1;

        int newArea = l * b;
        area = max(newArea, area);
    }
    return area;
}

int main()
{
    int n;
    cout << "Size of the array: ";
    cin >> n;

    vector<int> height(n);

    cout << "Enter the elements in the vector\n";
    for (int i = 0; i < n; i++)
    {
        cin >> height[i];
    }

    int ans = largestAreaRectangle(height);
    cout << ans << endl;
    return 0;
}