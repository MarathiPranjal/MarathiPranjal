/*  Input Restricted Queue: In this type of queue, insertion is allowed only from one side i.e. rear, but
    the deletion is allowed from both front and rear side.

    Output Restricted Queue: In this type of queue, insertion is allowed from both front and rear side, but
    the deletion is allowed only from one side i.e. front.      */